﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace studenti
{
    internal class Factory
    {
        private static Student[] students;
        static Factory()
        {
            students = new Student[0];
        }
        public static void Show()
        {
            if (students == null)
            {
                Console.WriteLine("Your array is null");
                return;
            }
            for (int i = 0; i < students.Length; i++)
            {
                Console.WriteLine(students[i].ToString());
            }
        }
        public static void GroupCreation(Student[] studentos)
        {
            //int count = 0;
            //if (studentos == null)
            //{
            //    Console.WriteLine("There is no any student");
            //}
            //for (int i = 0; i < students.Length; i++)
            //{

            //    for (int j = 0; j < studentos.Length; j++)
            //    {
            //        if (students[i].Specialization == studentos[j].Specialization)
            //        {
            //            Console.WriteLine("Sorry mate cant add");
            //        }
            //        for (int k = 0; k < studentos[j].Courses.Length; k++)
            //        {
            //            if (studentos[j].Courses.Contains(students[i].Courses[k]))
            //            {

            //                count++;
            //            }
            //            if (count >= 3)
            //            {
            //                Console.WriteLine("student added");

            //            }


            //        }
            //    }


            //}
            
            if (studentos == null)
            {
                Console.WriteLine("There is no any student");
                return;
            }
            Array.Resize(ref students, studentos.Length);
            students[0] = studentos[0];
            for (int i = 1; i < students.Length; i++) {
                int count = 0;
                if (studentos[i].Specialization == students[0].Specialization)
                {
                    Console.WriteLine("sorry mate you cant hop in");
                    return;
                }
              for(int j = 1; j < 6; j++)
                {
                    for(int k = 1; k < 6; k++) {
                        if (studentos[i].Courses[j] == students[0].Courses[k])
                        {
                            count++;
                        }
                    }
                    
                }
              if(count >= 3)
                {
                    Console.WriteLine($"You passed number {i + 1} ");
                    students[i] = studentos[i];
                }
                
            }
        }
    }
}


